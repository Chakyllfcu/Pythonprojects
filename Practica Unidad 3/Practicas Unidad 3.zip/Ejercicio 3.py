import requests
from json import loads
print("Programa que acepte un RNC de RD mostrar el nombre de la empresa\n")
validacion = False

while not validacion:
    rnc = input("Inserte su RNC: ")
    if len(rnc) >= 1:
        validacion = True
    else:
        print('Debe insertar valores.')

urlx = "https://api.adamix.net/apec/rnc/"+rnc
datos = requests.get(urlx)
objeto = loads(datos.text)
print("El nombre de la empresa es "+objeto['NOMBRE_COMERCIAL'])
